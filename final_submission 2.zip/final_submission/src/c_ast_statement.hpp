//
//  c_ast_statement.hpp
//  c_compiler
//
//  Created by Tom on 17/03/2016.
//  Copyright © 2016 Tom Hartley. All rights reserved.
//

#ifndef c_ast_statement_hpp
#define c_ast_statement_hpp

#include <stdio.h>
#include "c_ast.hpp"

class ASTStatement : public ASTNode {
public:
};


#endif /* c_ast_statement_hpp */
