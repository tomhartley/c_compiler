//
//  predefs.hpp
//  c_compiler
//
//  Created by Tom on 17/03/2016.
//  Copyright © 2016 Tom Hartley. All rights reserved.
//

#ifndef predefs_h
#define predefs_h

#include "c_ast.hpp"
#include "c_tokens.hpp"
#include "c_ast_statement.hpp"
#include "c_ast_statement_compound.hpp"
#include "c_ast_function.hpp"

#endif /* predefs_h */
